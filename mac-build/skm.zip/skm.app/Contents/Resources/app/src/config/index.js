module.exports = JSON.parse(require('fs').readFileSync(`${__dirname}/../../config.json`))
