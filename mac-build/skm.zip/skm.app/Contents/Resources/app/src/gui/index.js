const execute = function (argv, callback) {
  console.error("GUI not yet implemented!")
  callback()
}

module.exports = {
  execute: execute
}