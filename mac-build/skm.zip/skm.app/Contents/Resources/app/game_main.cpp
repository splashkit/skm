#include <iostream>
#include <unistd.h>
#include "utils.h"
using namespace std;

int main()
{
  int x;
  cout << "Enter a number" << endl;
  cin >> x;
  cout << "Starting Delay of" << endl;
  delay(x);
  cout << "Your number is: " << x << endl;

  return 0;
}