const execute = function (argv, callback) {
  console.error("GUI not yet implemented yet :()!")
  callback()
}

module.exports = {
  execute: execute
}